it is my ubuntu's vim config file 
using plugin
bufexplorer winmanager taglist tagexplorer

plugin installed i
ctags cscope 
